package edu.battle.player;

/**
 * Created by Aleksandr on 19.11.2016.
 */
public interface Player {
}
