package edu.battle.ship;

/**
 * Created by Aleksandr on 19.11.2016.
 */
public class Cruiser implements Ship{
}
