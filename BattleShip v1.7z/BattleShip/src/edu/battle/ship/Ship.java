package edu.battle.ship;

/**
 * Created by Aleksandr on 19.11.2016.
 */
public interface Ship {
}
